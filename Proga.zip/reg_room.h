#ifndef REG_ROOM_H
#define REG_ROOM_H

#include <QDialog>

namespace Ui {
class reg_room;
}

class reg_room : public QDialog
{
    Q_OBJECT

public:
    explicit reg_room(QWidget *parent = nullptr);
    ~reg_room();
    QString getName();
    QString getPass();
    QString checkProf();
    bool checkPass();

signals:
    void register_button_clicked2();

private slots:
    void on_line_Name_Reg_textEdited(const QString &arg1);

    void on_line_Pass_Reg_textEdited(const QString &arg1);

    void on_line_Conf_Reg_textEdited(const QString &arg1);

    void on_Reg_Button_clicked();
private:
    Ui::reg_room *ui;
    QString m_userName;
    QString m_userPass;
    QString m_confirmation;
    QString m_prof;
};

#endif // REG_ROOM_H
