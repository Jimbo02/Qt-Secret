#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QString>
#include <QtSql/QtSql>
#include "authentification.h"
#include "reg_room.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void display();
    bool connectDB();

private:
    Ui::MainWindow *ui_Main;

    authentification ui_auth;//экземпляры окна авторизации
    reg_room ui_reg;//и регистрации

    QString m_username;//строка для обработки логина
    QString m_userpass;//и пароля

    QString m_prof;//строка для выявления должности

    QString db_input;// строка для отправки запроса к базе данных

    QSqlDatabase mw_db;//Экземпляр подключения к базе данных

    int user_counter;//Счетчик пользователей
    bool m_loginSuccesfull;//успешный вход

private slots:
    void authorizeUser();//Пользовательские слоты
    void registerWindowShow();
    void registerUser();
};
#endif // MAINWINDOW_H
