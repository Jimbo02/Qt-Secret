#include "winadmin.h"
#include "ui_winadmin.h"

winadmin::winadmin(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::winadmin)
{
    ui->setupUi(this);
}

winadmin::~winadmin()
{
    delete ui;
}
