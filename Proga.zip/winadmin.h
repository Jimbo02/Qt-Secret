#ifndef WINADMIN_H
#define WINADMIN_H

#include <QDialog>

namespace Ui {
class winadmin;
}

class winadmin : public QDialog
{
    Q_OBJECT

public:
    explicit winadmin(QWidget *parent = nullptr);
    ~winadmin();

private:
    Ui::winadmin *ui;
};

#endif // WINADMIN_H
