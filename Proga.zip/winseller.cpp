#include "winseller.h"
#include "ui_winseller.h"

winseller::winseller(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::winseller)
{
    ui->setupUi(this);
}

winseller::~winseller()
{
    delete ui;
}
