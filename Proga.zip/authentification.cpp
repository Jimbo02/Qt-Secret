#include "authentification.h"
#include "ui_authentification.h"

authentification::authentification(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::authentification)
{
    ui->setupUi(this);
}

authentification::~authentification()
{
    delete ui;
}


void authentification::on_Button_Login_clicked()
{
    emit login_button_clicked();
}


void authentification::on_Button_Register_clicked()
{
    emit register_button_clicked();
}

void authentification::on_Line_Name_textEdited(const QString &arg1)
{
    authentification::m_username = arg1;
}


void authentification::on_Line_Password_textEdited(const QString &arg1)
{
    authentification::m_userpass = arg1;
}

QString authentification::getLogin()
{
    return authentification::m_username;
}

QString authentification::getPass()
{
    return authentification::m_userpass;
}
