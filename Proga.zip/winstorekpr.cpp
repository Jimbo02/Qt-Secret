#include "winstorekpr.h"
#include "ui_winstorekpr.h"

winstorekpr::winstorekpr(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::winstorekpr)
{
    ui->setupUi(this);
}

winstorekpr::~winstorekpr()
{
    delete ui;
}
