#include "reg_room.h"
#include "ui_reg_room.h"

reg_room::reg_room(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::reg_room)
{
    ui->setupUi(this);
    ui->Seller->setChecked(true);
}

reg_room::~reg_room()
{
    delete ui;
}

void reg_room::on_Reg_Button_clicked()
{
    if (ui->Admin->isChecked())
    {
        reg_room::m_prof = "administrator";
    }
    else if (ui->Seller->isChecked())
    {
        reg_room::m_prof = "seller";
    }
    else
    {
        reg_room::m_prof = "storekpr";
    }
    emit register_button_clicked2();
}

void reg_room::on_line_Name_Reg_textEdited(const QString &arg1)
{
    reg_room::m_userName = arg1;
}


void reg_room::on_line_Pass_Reg_textEdited(const QString &arg1)
{
    reg_room::m_userPass = arg1;
}


void reg_room::on_line_Conf_Reg_textEdited(const QString &arg1)
{
    reg_room::m_confirmation = arg1;
}


QString reg_room::getName()
{
    return m_userName;
}

QString reg_room::getPass()
{
    return m_userPass;
}

bool reg_room::checkPass()
{
    return (m_confirmation == m_userPass);
}

QString reg_room::checkProf()
{
    return m_prof;
}

