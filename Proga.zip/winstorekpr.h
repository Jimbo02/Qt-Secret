#ifndef WINSTOREKPR_H
#define WINSTOREKPR_H

#include <QDialog>

namespace Ui {
class winstorekpr;
}

class winstorekpr : public QDialog
{
    Q_OBJECT

public:
    explicit winstorekpr(QWidget *parent = nullptr);
    ~winstorekpr();

private:
    Ui::winstorekpr *ui;
};

#endif // WINSTOREKPR_H
