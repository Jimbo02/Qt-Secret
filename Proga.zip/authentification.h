#ifndef AUTHENTIFICATION_H
#define AUTHENTIFICATION_H

#include <QWidget>
namespace Ui {
class authentification;
}

class authentification : public QWidget
{
    Q_OBJECT

public:
    explicit authentification(QWidget *parent = nullptr);
    ~authentification();
    QString getLogin();
    QString getPass();

signals:
    void login_button_clicked();
    void register_button_clicked();

private slots:
    void on_Line_Name_textEdited(const QString &arg1);

    void on_Line_Password_textEdited(const QString &arg1);

    void on_Button_Login_clicked();

    void on_Button_Register_clicked();

private:
    Ui::authentification *ui;
    QString m_username;
    QString m_userpass;
    QString m_prof;
};

#endif // AUTHENTIFICATION_H
