#ifndef WINSELLER_H
#define WINSELLER_H

#include <QDialog>

namespace Ui {
class winseller;
}

class winseller : public QDialog
{
    Q_OBJECT

public:
    explicit winseller(QWidget *parent = nullptr);
    ~winseller();

private:
    Ui::winseller *ui;
};

#endif // WINSELLER_H
